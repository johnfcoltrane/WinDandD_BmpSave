#include <windows.h>
#include <iostream>
#include <string>
#include "libWstr.h"
#include "saveBmp.h"

extern "C" {
BYTE* p;
LPWSTR p2; //typedef WCHAR* LPWSTR;

HINSTANCE hInst;
HWND hwnd;
DWORD dwLength, dwWidth, dwHeight;
LPBITMAPINFO lpInfo;
LPBYTE lpPixel;
LPVOID lpBuf;
BOOL loaded;
}
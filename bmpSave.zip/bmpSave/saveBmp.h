#pragma once

#include "resource.h"

//extern "C" {
//LPWSTR Char2LPWSTR(void* buf, BYTE* x);
LPWSTR Char2LPWSTR(BYTE* x);
//}
//extern "C" {
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
BOOL readBMP(LPVOID);
void greenScale(void);
void saveBMP(LPBYTE*, LPBITMAPINFO, LPBYTE);
//}
